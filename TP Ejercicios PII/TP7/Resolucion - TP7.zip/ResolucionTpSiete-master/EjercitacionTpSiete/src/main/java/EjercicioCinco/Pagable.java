package EjercicioCinco;

public interface Pagable {
    // Declaramos el metodo pagar
    void pagar();
}
