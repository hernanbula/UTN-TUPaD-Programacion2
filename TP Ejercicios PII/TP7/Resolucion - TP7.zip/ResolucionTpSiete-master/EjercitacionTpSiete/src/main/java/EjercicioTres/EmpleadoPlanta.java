package EjercicioTres;

public class EmpleadoPlanta extends Empleado{ // Extendemos de empleado
    
}
