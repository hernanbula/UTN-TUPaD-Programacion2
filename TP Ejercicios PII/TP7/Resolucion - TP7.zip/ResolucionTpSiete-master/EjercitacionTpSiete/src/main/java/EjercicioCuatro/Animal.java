package EjercicioCuatro;

public class Animal {
    // Creamos el metodo hacer sonido
    public void hacerSonido(){
        
    }
    
    public void describirAnaimal(){
        
    }
}
