package EjercicioTres;

public class EmpleadoTemporal extends Empleado{ //Extendemos de empleado
    
}
