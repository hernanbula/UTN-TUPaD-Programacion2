package EjercicioDos;


public abstract class Figura {
    // Declaramos el atributo protegido nombre
    protected String nombre;

    // Creamos el constructor de figura
    public Figura(String nombre) {
        this.nombre = nombre;
    }
    
    // Creamos el  metodo calcular area
    public void calcularArea(){
    }
}
