package EjercicioUno;

public class Main {

    public static void main(String[] args) {
        // Instanciamos un auto
        Auto a = new Auto(5, "Renault", "Sandero");
        
        // Llamamos al metodo para mostrar su informacion
        a.mostrarInfo();
    }
    
}
